const { DataTypes } = require("sequelize");
const sequelize = require("../config/config");

const Atleta = sequelize.define('atleta', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    descricao: {
        type: DataTypes.STRING,
        allowNull: false
    },
    nota: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
});

module.exports = Atleta;