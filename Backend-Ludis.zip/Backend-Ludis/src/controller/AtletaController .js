const Atleta = require("../models/Atleta");

const AtletaController = {
  create: async (req, res) => {
    try {
      const { nome, descricao, nota } = req.body;

      const atletaCriado = await Atleta.create({ nome, descricao, nota });

      return res.status(200).json({
        msg: "Atleta cadastrado com sucesso!",
        user: atletaCriado,
      });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ msg: "Acione o Suporte" });
    }
  },
  update: async (req, res) => {
    try {
      const { id } = req.params;
      const { nome, descricao, nota } = req.body;

      console.log({ id });
      console.log({ nome, descricao, nota });

      const atletaUpdate = await Atleta.findByPk(id);

      if (atletaUpdate == null) {
        return res.status(404).json({
          msg: "Atleta nao encontrado",
        });
      }

      const updated = await atletaUpdate.update({
        nome, 
        descricao, 
        nota
      });
      if (updated) {
        return res.status(200).json({
          msg: "Atleta atualizado com sucesso!",
        });
      }
    return res.status(500).json({
        msg:"Erro ao atualizar atleta"
    })
    } catch (error) {
      console.error(error);
      return res.status(500).json({ msg: "Acione o Suporte" });
    }
  },
  getAll: async (req, res) => {
    try {
      const atletas = await Atleta.findAll();
      return res.status(200).json({
        msg: "Atleta Encontrados!",
        atletas,
      });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ msg: "Acione o Suporte" });
    }
  },
  getOne: async (req, res) => {
    try {
      const { id } = req.params;

      const atletaEncontrado = await Atleta.findByPk(id);

      if (atletaEncontrado == null) {
        return res.status(404).json({
          msg: "Atleta nao encontrado!",
        });
      }
      return res.status(200).json({
        msg: "Atleta Encontrados",
        usuario: atletaEncontrado,
      });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ msg: "Acione o Suporte" });
    }
  },
  delete: async (req, res) => {
    try {
      const { id } = req.params;

      const atletaFinded = await Atleta.findByPk(id);

      if (atletaFinded == null) {
        return res.status(404).json({
          msg: "Atleta nao encontrado",
        });
      }
      await atletaFinded.destroy();

      return res.status(200).json({
        msg: "Atleta deletado com sucesso",
      });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ msg: "Acione o Suporte" });
    }
  },
};

module.exports = AtletaController;
