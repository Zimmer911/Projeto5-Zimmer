const {Router} = require("express");
const AtletaController = require("../controller/AtletaController ");
const { validateAtleta, validateAtletaId } = require("../middlewares/ValidateAtleta");

const router = Router();

router.post('/',validateAtleta,(req,res) => {
    AtletaController.create(req,res)
});
router.put('/:id',validateAtleta,validateAtletaId,(req,res) => {
    AtletaController.update(req,res)
});
router.get('/',(req,res) => {
    AtletaController.getAll(req,res)
});
router.get('/:id',validateAtletaId,(req,res) => {
    AtletaController.getOne(req,res)
});
router.delete('/:id',validateAtletaId,(req,res) => {
    AtletaController.delete(req,res)
});

module.exports = router;