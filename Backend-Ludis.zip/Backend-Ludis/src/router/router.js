const { Router } = require("express");
const userRoutes = require("./routerUser");
const atletaRoutes = require("./routerAtleta");
const UserController = require("../controller/UserController");
const authenticateToken = require("../middlewares/authenticateToken");

const uploadRoutes = require('./routerUpload');

const router = Router();

router.use('/atleta', atletaRoutes);

router.use('/image', uploadRoutes);

router.use('/user', userRoutes);

module.exports = router;